#! /usr/bin/env python3
# -*- coding: utf-8 -*-
import os, sys, subprocess, requests
import random
import bs4 as bs4
import time
import datetime
import telebot
from telebot import apihelper
import hashlib
import json
##################################################################################################################
#ЦЕНЫ
PRICE_RDP = 0
PRICE_SOCKS4 = 0
PRICE_SOCKS5 = 0
PRICE_NORDVPN50 = 50
PRICE_NORDVPN100 = 100
PRICE_NORDVPN150 = 150
##################################################################################################################

##################################################################################################################
token = '655402396:AAH0ax1TDGnX-AaPmHKhAvawOlXwdWVVpDs' #vds2018
#token = '881030199:AAHowXHOM-zfu9B4kY5slSGEhuZ6hE9TpL4' #newJabber
bot = telebot.TeleBot(token)#создаем экземпляр бота

file_name = 'setings/setting.txt'
transfer_history = 'setings/transfer.txt'
api_access_token = '17af9d29bd4e046cd2598b0a37af447d' 
my_login = '+79042316558' # номер QIWI Кошелька в формате +79991112233
s = requests.Session()
s.headers['authorization'] = 'Bearer ' + api_access_token
##################################################################################################################
# Статические переменные 
admin_account = 'admin-rdp-shop@xmpp.jp'
adverte = 'adverte.txt'
rdp = 'free/rdp.txt'
start_time = time.time()
start_data_time = datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")
msg_counter = 0
adverte_count = 0
spam_text = ":)"
admin_id = 458317278
last_user = 0
restart_count=0
##################################################################################################################
# Статические переменные для сообщений
HR = '''============='''

tranzaction_used ="Транзакция уже использована"
prod_added = "Товар добавлен"
eror_city = "Неверно указан город!"
spam_end = "Рассылка окончена."
you_no_admin = "У вас нет прав для рассылки спама с этого бота!"

HELP_MESSAGE = '''
==Раздел справки==
Список команд бота:
/help - Это сообщение
/shop - Магазин автопродаж
/time - Показывает Московское время
/weather - Показывает погоду Пример: /погода москва
/about - узнать информацию о разработчике
/anek- случайный анекдот
'''
ABOUT_MESSAGE = '''
==Сod3r by Mad1k==
Jabber: admin-rdp-shop@xmpp.jp
Telegram: MyMotherSay
'''
PRICE_MESSAGE = '''
😎😎😎Приветствую тебя друг!!!😎😎😎
👩‍💻Хочу представить твоему вниманию.👩‍💻
👍🏻@vds2018_chanel наш канал новостей📈
👍🏻@vds2018_chat наш чат 📨
👍🏻@vds2018_shop_bot  бот автопродаж🏦
                      👉Заходи👈
В данныей момент в наличии:
=============================
💻RDP - Нет в наличии
=============================
🔐Socks4 - 0 Rub /buy_socks4 <-- FREE
=============================
🔐Socks5 - 0 Rub /buy_socks5 <-- FREE
=============================
🔐NordVPN
До 2020 - 50 Rub /buy_nordvpn50
До 2021 - 100 Rub /buy_nordvpn100
До 2022 - 150 Rub /buy_nordvpn150
=============================
🔎В случае невалида сделаем замену🔍
               🏛@MyMotherSay🏛
=============================
Приглашаю к сотрудничеству продавцов
'''
EROR_MESSAGE = '''
==Неверная команда==
Для просмотра справки напишите /помошь
'''
INFO_MESSAGE = '''
Данный бот находиться в стадии разработки,
присылайте свои предложения разработчику бота
'''
SHOP_RULES_MESSAGE='''
/price - посмотреть товары и цены на них
/balance - проверить баланс
/check_pay_help - как полполнить баланс 
/check_pay - пополнить баланс
/buy_rdp - купить дедик
/buy_socks4 - купить socks4
/buy_socks5 - купить socks5
/buy_nordvpn50 - купить ключ nordvpn до 2020
/buy_nordvpn100 - купить ключ nordvpn до 2021
/buy_nordvpn150 - купить ключ nordvpn до 2022

'''

CHECK_PAY_HELP = '''
Для пополнения вашего баланса,
необходимо сделать следушее:
1. Сделать пополнение нашего кошелька,
 Номер кошелька 79042316558
2. После оплаты нужно отправить,
 номер квитанции
3. Пример:
 /check_pay 22812381238
4.После чего ваш баланс
пополниться и вы сможете 
совершать покупки.
'''

##################################################################################################################
# Плюшки
def search_transfer(user_id,input_data):
	myfile = open(transfer_history,'r',encoding='utf-8')# открыли файл для чтения 
	json_data = json.load(myfile)# получили данные из файла
	myfile.close()# закрыли файл
	for line in json_data: # перебираем всех пользователей 
		id = int(line["id"]) # присвоили значение ид в базе
		uid = int(line["uid"]) #присвоили значения чат ид
		tranz = int(line["tranz"])
		summa = int(line["summa"])
		print('var = ', type(id),id,type(uid),uid,type(tranz),tranz,type(summa),summa)
		if int(input_data) == int(tranz):
			if_exist = True
			print('transfer exist')
			break
		else:
			if_exist = False
	return if_exist
def reg_transfer(user_id,tranzaction,summa,data):
	count = 0
	myfile = open(transfer_history,'r',encoding='utf-8')
	json_data = json.load(myfile)
	myfile.close()
	for user in json_data:
		id = int(user["uid"])		
		count = count + 1
	myfile = open(transfer_history,'r',encoding='utf-8')# открыли файл для чтения 
	json_data = json.load(myfile)# получили данные из файла
	myfile.close()# закрыли файл

	transfer = {'id': count, 'uid': user_id,'tranz': tranzaction,'summa': summa,'data':data}	
	transfers = json_data +[transfer] # дописали к файлу нового участника
	
	myfile = open(transfer_history,'w',encoding='utf-8') # открыли файл на запись
	json.dump(transfers,myfile) # записали данные в файл
	myfile.close()#закрыли файл
def getQiwiBalance():
	response = s.get('https://edge.qiwi.com/funding-sources/v2/persons/'+my_login+'/accounts')
	json_resp = json.loads(response.text)
	accounts = json_resp.get("accounts")
	accounts = accounts[0]
	balance = accounts.get('balance')
	money = balance.get('amount')
	return money
def getHistory(user_id,input_data):
	#Проверяем транзацкции
	if search_transfer(user_id,input_data) == True:
		return tranzaction_used
	else:
		parameters = {'rows': '5','operation':'IN'}
		h = s.get('https://edge.qiwi.com/payment-history/v1/persons/'+my_login+'/payments', params = parameters)
		json_resp = json.loads(h.text)
		data = json_resp.get("data")
		#print(json_resp)
		for x in range(0,5):
			stroka = data[x]	
			txnId= stroka.get('txnId')#ID транзакции в процессинге QIWI Wallet
			personId = stroka.get('personId')#	Номер кошелька
			date = stroka.get('date')# Дата/время платежа, во временной зоне запроса
			status = stroka.get('status')#Статус платежа. Возможные значения:WAITING - платеж проводится, SUCCESS - успешный платеж, ERROR - ошибка платежа.
			is_in_type = stroka.get('type')# Тип платежа. Возможные значения:IN - пополнение, 
			trmTxnId = stroka.get('trmTxnId')#Клиентский ID транзакции
			account = stroka.get('account')#Для платежей - номер счета получателя.		
			money = stroka.get('sum')#Данные о сумме платежа или пополнения. 		
			amount = money.get("amount")#сумма
			comment = stroka.get("comment")# Комментарий к платежу
			input_data = int(input_data)
			if txnId == input_data:
				print('find',user_id,amount)
				reg_transfer(user_id,txnId,amount,date)
				return add_balance(user_id,amount)
def reg_user(userid):
	id = int(user_conunt())+1 # Получаем общее количество пользователей и инкремент 1
	print(id)
	print(type(id))
	user = {'id': id, 'uid': userid,'balance': 5,'group': "user"} #Обьявили список создали пользователя
	myfile = open(file_name,'r',encoding='utf-8')# открыли файл для чтения 
	json_data = json.load(myfile)# получили данные из файла
	myfile.close()# закрыли файл
	myplayers = json_data +[user] # дописали к файлу нового участника
	myfile = open(file_name,'w',encoding='utf-8') # открыли файл на запись
	json.dump(myplayers,myfile) # записали данные в файл
	myfile.close()#закрыли файл
def if_exist_user(userid):# возврашает больше 0
	myfile = open(file_name,'r',encoding='utf-8')#открыли файл для чтения
	json_data = json.load(myfile)# считали всех пользователей
	myfile.close()#закрыли файл
	what = False # обьявил флаг для проверки существует пользователь или нет
	for user in json_data: # перебираем всех пользователей 
		id = str(user["id"]) # присвоили значение ид в базе
		uid = str(user["uid"]) #присвоили значения чат ид
		if int(userid) == int(uid): # если Чат ид запроса равена чат ид в базе
			what = True # ставим флаг существует
			return id #для возврата ид в базе
		else: #если нет
			what = False #ставим флаг не найден
	if what == False: # если не найден
		reg_user(userid) #регистрация нового пользователя
	else:
		pass
	#return True # возврат пользователь существует 
def is_admin(userid):
	myfile = open(file_name,'r',encoding='utf-8')
	json_data = json.load(myfile)
	myfile.close()
	for user in json_data:
		id = str(user["id"])
		uid = str(user["uid"])
		balance = str(user["balance"])
		group = str(user["group"])
		if int(userid) == int(uid) and group == 'admin':
			return True
		else:
			return False
def user_conunt():#возврашает больше 0
	count = 0
	myfile = open(file_name,'r',encoding='utf-8')
	json_data = json.load(myfile)
	myfile.close()
	for user in json_data:
		id = str(user["uid"])		
		balance = str(user["balance"])
		group = str(user["group"])
		count = count + 1
	return count
def check_balance(userid):#возврашает 0 или больше
	myfile = open(file_name,'r',encoding='utf-8')
	json_data = json.load(myfile)
	myfile.close()
	for user in json_data:
		uid = str(user["uid"])
		balance = str(user["balance"])
		if int(userid) == int(uid):
			return balance
		else:
			pass
def add_balance(userid,summ):
	myfile = open(file_name,'r',encoding='utf-8')#открыли файл для чтения
	json_data = json.load(myfile)# считали данные
	myfile.close()# закрыли
	colums = json_data[int(if_exist_user(userid))]
	id = colums.get('id')# достаем данные из слоаря
	uid = colums.get('uid')# достаем данные из слоаря
	balance = colums.get('balance')# достаем данные из слоаря
	group = colums.get('group') # достаем данные из слоаря
	balance = balance + summ # добавили сумму к существующему балансу
	colums.update({'id': id, 'uid': uid,'balance': balance,'group': group})#обновили баланс
	myfile = open(file_name,'w',encoding='utf-8') # открыли файл на запись
	json.dump(json_data,myfile) # записали данные в файл
	myfile.close()
	return 'Зачислено: {0} рублей'.format(summ)
def buy(userid,price):
	myfile = open(file_name,'r',encoding='utf-8')#открыли файл для чтения
	json_data = json.load(myfile)# считали данные
	myfile.close()# закрыли
	colums = json_data[int(if_exist_user(userid))]
	id = colums.get('id')# достаем данные из слоаря
	uid = colums.get('uid')# достаем данные из слоаря
	balance = colums.get('balance')# достаем данные из словаря
	group = colums.get('group') # достаем данные из словаря
	if balance <= 0:
		return "Ошибка, ваша баланс: " + str(balance)
	elif balance < int(price):
		return "Не достаточно средсв, ваша баланс: " + str(balance)
	else:
		balance = balance - price # вычли сумму 
		colums.update({'id': id, 'uid': uid,'balance': balance,'group': group})#обновили баланс
		myfile = open(file_name,'w',encoding='utf-8') # открыли файл на запись
		json.dump(json_data,myfile) # записали данные в файл
		myfile.close()
		return True
def product_count(file_name):
	count = 0
	myfile = open(file_name,'r',encoding='utf-8')
	json_data = json.load(myfile)
	myfile.close()
	for user in json_data:
		id = str(user["id"])		
		data = str(user["data"])
		status = str(user["status"])
		count = count + 1
	return count
def add_product(category, data):
	file_name = ''
	if category == 'rdp':
		file_name = 'files/rdp.txt'
	elif category == 'socks4':
		file_name = 'files/socks4.txt'
	elif category == 'socks5':
		file_name = 'files/socks5.txt'
	elif category == 'nordvpn50':
		file_name = 'files/nordvpn50.txt'
	elif category == 'nordvpn':
		file_name = 'files/nordvpn100.txt'
	elif category == 'nordvpn':
		file_name = 'files/nordvpn150.txt'
	id = product_count(file_name)
	product= {'id': id, 'data': data,'status': False} #Обьявили список и добавили данные
	
	myfile = open(file_name,'r',encoding='utf-8')# открыли файл для чтения 
	json_data = json.load(myfile)# получили данные из файла
	myfile.close()# закрыли файл
	products = json_data +[product]
	myfile = open(file_name,'w',encoding='utf-8') # открыли файл на запись
	json.dump(products,myfile) # записали данные в файл
	myfile.close()#закрыли файл
	return prod_added
def buy_product(userid,price,category):
	if buy(userid,price) == True:
		return get_product(category)
	else:
		return buy(userid,price)
def get_product(category):
	# True продан  False не продан
	file_name = ''
	if category == 'rdp':
		file_name = 'files/rdp.txt'
	elif category == 'socks4':
		file_name = 'files/socks4.txt'
	elif category == 'socks5':
		file_name = 'files/socks5.txt'
	elif category == 'nordvpn50':
		file_name = 'files/nordvpn50.txt'
	elif category == 'nordvpn100':
		file_name = 'files/nordvpn100.txt'
	elif category == 'nordvpn150':
		file_name = 'files/nordvpn150.txt'
	
	myfile = open(file_name,'r',encoding='utf-8')#открыли файл для чтения
	json_data = json.load(myfile)# считали данные
	myfile.close()# закрыли
	count = find_produsct(file_name)
	colums = json_data[count]
	uid = colums.get('id')# достаем данные из слоаря
	data = colums.get('data')# достаем данные из слоаря
	status = True # достаем данные из словаря
	print('var = ', type(id),id,type(data),data,type(status),status)
	colums.update({'id':uid,'data':data,'status': status})#обновили статус
	myfile = open(file_name,'w',encoding='utf-8') # открыли файл на запись
	json.dump(json_data,myfile) # записали данные в файл
	myfile.close()
	return data
def find_produsct(file_name):
	myfile = open(file_name,'r',encoding='utf-8')#открыли файл для чтения
	json_data = json.load(myfile)# считали всех пользователей
	myfile.close()#закрыли файл
	what = False # обьявил флаг для проверки существует пользователь или нет
	for user in json_data: # перебираем всех пользователей 
		id = int(user['id']) # присвоили значение ид в базе	
		data = str(user['data']) #присвоили значения чат ид
		status = bool(user['status'])
		print('var = ', type(id),id,type(data),data,type(status),status)
		if status == False :
			what = True
			return id
			break
		else: #если нет
			what = False #ставим флаг не найден
			pass
	return 0
def get_stat():
	seconds = int(time.time() - start_time)
	days = seconds // 86400
	hourse = seconds // 3600
	minute = seconds // 60
	today = datetime.date.today()
	return '''
	Запущен: {0}
	Время работы бота:
 Секунд: {1}
 Минут:  {2}
 Часов:  {3}
 Дней:   {4}
	Всего запросов к боту: {5}
	Сегодня: {6}
	Показано реклам: {7}
	'''.format(start_data_time,seconds,minute,hourse,days,msg_counter,today,adverte_count)
def _clean_all_tag_from_str(string_line):
	"""Очистка текста от лишних тегов"""
	result = ""
	not_skip = True
	for i in list(string_line):
		if not_skip:
			if i == "<":
				not_skip = False
			else:
				result += i
		else:
			if i == ">":
				not_skip = True
	return result
def get_weather(city):
	"""Запрос на получение погоды"""
	try:
		request = requests.get(u"https://sinoptik.com.ru/погода-" + city)
		b = bs4.BeautifulSoup(request.text, "html.parser")
		p3 = b.select('.temperature .p3')
		weather1 = p3[0].getText()
		p4 = b.select('.temperature .p4')
		weather2 = p4[0].getText()
		p5 = b.select('.temperature .p5')
		weather3 = p5[0].getText()
		p6 = b.select('.temperature .p6')
		weather4 = p6[0].getText()
		result = ''
		result = result + ('\n' + u'Утром :' + weather1 + ' ' + weather2)
		result = result + ('\n' + u'Днём :' + weather3 + ' ' + weather4)
		temp = b.select('.rSide .description')
		weather = temp[0].getText()
		result = '\n' + weather.strip() + result
	except:
		result = eror_city
	return result
def get_time():
	try:
		request = requests.get("https://my-calend.ru/date-and-time-today")
		b = bs4.BeautifulSoup(request.text, "html.parser")
		result = _clean_all_tag_from_str(str(b.select(".page")[0].findAll("h2")[1])).split()[1]
	except:
		result = 'Eror'
	return '\n Время: ' + result
def get_text(afile):
	"""Считываем случайную строчку из файла"""
	try:
		lines = open(afile).read().splitlines()
		return random.choice(lines)
	except:
		print("NO FILE IN DIRECTORY!!!")
		return None
def get_adv():
	"""Показ рекламы"""
	global adverte_count
	adverte_count = adverte_count + 1
	try:
		text = "\nРеклама: " +  get_text(adverte)
	except:
		text = "Приглашаем к сотрудничеству!"
	return text
def get_anek():
	url = "https://bash.im/random"
	request = requests.get(url)
	b = bs4.BeautifulSoup(request.text, "html.parser")
	b = b.find('div',class_='quote__body')
	return b.text
def spam(spam_text):
	"""Переписать под json"""
	spam_text
	f = open('users.txt','r')
	for line in f:
		bot.send_message(line, spam_text)
	f.close()
def my_restart():
	global restart_count
	restart_data_time = datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")
	print('Bot restarted: ',restart_count, 'time: ', restart_data_time)
	restart_count = restart_count + 1
	time.sleep(30)
	main()

##################################################################################################################
# Парсер команд
def start_menu(chat_id,text):
	global msg_counter
	msg_counter = msg_counter + 1
	try:
		text = text.replace(';',' ')
	except:
		pass
	try:
		cmd = text.split()[0]
	except:
		cmd = ''
	try:
		arg = text.split()[1]
	except:
		arg = ''
	try:
		city = text.split()[1]
	except:
		city = u'москва'
	try:
		arg1 = text.split()[2]
	except:
		arg1 = ''
	try:
		if cmd == u'/помошь' or cmd == '/help' or cmd == u'помошь':
			return HELP_MESSAGE
		elif cmd == u'/оботе' or cmd == '/about' or cmd == u'оботе':
			return ABOUT_MESSAGE + get_stat()
		elif cmd == u'/время' or cmd == '/time' or cmd == u'время':
			return get_time()
		elif cmd == u'/погода' or cmd == '/weather' or cmd == u'погода':
			return get_weather(city)		
		elif cmd == u'/анекдот' or cmd == '/anek' or cmd == u'анекдот':
			return get_anek()
		elif cmd == '/stat':
			return get_stat()
##################################################################################################################
#команды для магазина
		elif cmd =='/shop' :
			return SHOP_RULES_MESSAGE
		elif cmd == '/price':
			return PRICE_MESSAGE
		elif cmd =='/balance' :
			return check_balance(chat_id) + ' RUB'
		elif cmd =='/add_rdp' :
			print(arg)
			return add_product('rdp', arg)
		elif cmd =='/add_socks4' :
			return add_product('socks4', arg)
		elif cmd =='/add_socks5' :
			return add_product('socks5', arg)
		elif cmd =='/add_nordvpn50' :
			return add_product('nordvpn50', arg)
		elif cmd =='/add_nordvpn100' :
			return add_product('nordvpn100', arg)
		elif cmd =='/add_nordvpn150' :
			return add_product('nordvpn150', arg)
		elif cmd == '/check_pay_help':
			return CHECK_PAY_HELP
		elif cmd =='/check_pay' :
			return getHistory(chat_id,arg)
		elif cmd == '/buy_rdp' :
			return buy_product(chat_id,PRICE_RDP,'rdp')
		elif cmd == '/buy_socks4' :
			return buy_product(chat_id,PRICE_SOCKS4,'socks4')
		elif cmd == '/buy_socks5' :
			return buy_product(chat_id,PRICE_SOCKS5,'socks5')
		elif cmd == '/buy_nordvpn50' :
			return buy_product(chat_id,PRICE_NORDVPN50,'nordvpn50')
		elif cmd == '/buy_nordvpn100' :
			return buy_product(chat_id,PRICE_NORDVPN100,'nordvpn100')
		elif cmd == '/buy_nordvpn150' :
			return buy_product(chat_id,PRICE_NORDVPN150,'nordvpn150')
##################################################################################################################
		elif cmd == '/qiwi_mod' :
			return getQiwiBalance()
##################################################################################################################
		elif cmd == '/spam':
			if int(chat_id) == int(admin_id):
				text = text[6:len(text)]
				spam(text)
				return spam_end
			else:
				return you_no_admin
	except:
		Eror_date_time = datetime.datetime.today().strftime("%Y-%m-%d-%H.%M.%S")
		print(Eror_date_time,' EROR_LOG ', chat_id,text)
		pass
##################################################################################################################
# Основной поток обработки сообщений
@bot.message_handler(commands=['start'])
def start_message(message):
	user = message.chat.id
	if_exist_user(user)
	bot.send_message(message.chat.id, HELP_MESSAGE)

@bot.message_handler(content_types=['text'])
def send_text(message):
	user = message.chat.id
	text = message.text.lower()
	
	reply = start_menu(user,text)#парсим на наличие команд
	try:
		bot.send_message(message.chat.id, reply)#отправляем ответ
		bot.send_message(message.chat.id, get_adv())#отправляем рекламу
	except:
		bot.send_message(message.chat.id, get_adv())#отправляем рекламу
def main():
	try:
		bot.polling()#запуск бота
	except:
		my_restart()


if __name__ == '__main__':
	main()

